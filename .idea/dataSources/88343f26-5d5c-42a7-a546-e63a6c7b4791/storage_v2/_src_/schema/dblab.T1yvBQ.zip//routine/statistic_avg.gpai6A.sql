create
    definer = root@localhost procedure statistic_avg()
begin
    declare currName char(20);
    declare currCno char(9);
    declare currAvg numeric(10,6);
    declare done int default 0;
    -- 声明不带参数的游标myCursor查询课程号和课程名称
    declare  myCursor cursor for select `Cno`,`Cname` from `course`;
    -- 捕获系统抛出的 not found 错误，如果捕获到，将 done 设置为 1  相当于try异常
    declare continue handler for not found set done=1;
    open myCursor;
        www:loop
            -- 游标推进一行取结果赋值给变量
            fetch myCursor into currCno,currName;
            -- 如果没有返回值，则退出循环
            if done=1 then
                leave www;
            end if;
            select AVG(`Grade`) into currAvg from `sc` where `Cno`=currCno;
            insert into `avgGrade`(`Cname`,`CAvg`) values (currName,currAvg);
        end loop;
    close myCursor;
end;

