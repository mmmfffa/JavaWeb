create
    definer = root@localhost procedure statistic_change()
begin
    declare chGrade char(2);
    declare currSno char(9);
    declare currCno char(9);
    declare currGrade float;
    declare done int default 0;
    -- 声明不带参数的游标myCursor查询课程号和课程名称
    declare  myCursor cursor for select `Sno`,`Cno`,`Grade` from `sc`;
    -- 捕获系统抛出的 not found 错误，如果捕获到，将 done 设置为 1  相当于try异常
    declare continue handler for not found set done=1;
    open myCursor;
         www:loop
             -- 游标推进一行取结果赋值给变量
             fetch myCursor into currSno,currCno,currGrade;
             -- 如果没有返回值，则退出循环
             if done=1 then
                 leave www;
             end if;
             if currGrade<60 then
                 select `cGrade` into chGrade from `changeGrade` where `num`=1;
             end if;
             if currGrade>=60 and currGrade<70 then
                 select `cGrade` into chGrade from `changeGrade` where `num`=2;
             end if;
             if currGrade>=70 and currGrade<80 then
                 select `cGrade` into chGrade from `changeGrade` where `num`=3;
             end if;
             if currGrade>=80 and currGrade<90 then
                 select `cGrade` into chGrade from `changeGrade` where `num`=4;
             end if;
             if currGrade>=90 and currGrade<101 then
                 select `cGrade` into chGrade from `changeGrade` where `num`=5;
             end if;
             
             update `sc` set sc.`newGrade`=chGrade where `Sno`=currSno and `Cno`=currCno;
         end loop;
    close myCursor;
end;

